export 'package:seminariovalidacion/screens/home_screen.dart';
export 'package:seminariovalidacion/screens/login_screen.dart';
export 'package:seminariovalidacion/screens/registrar_screen.dart';
export 'package:seminariovalidacion/screens/product_screen.dart';
export 'package:seminariovalidacion/screens/loading_screen.dart';
